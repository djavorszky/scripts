#/bin/bash

cp -rv /home/jdaniel/bin/* /home/jdaniel/Dropbox/scripts
